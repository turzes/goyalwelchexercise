Section C.

We provide the R-package, "quantilogram_0.1.tar.gz", and its manual. 
As explained in the manual, the package includes data for the 
applications presented in our paper and contains critical values
for the self-normalized statistics. We also provide two R-codes,
"Application_StockReturn.R" and Application_SystemicRisk.R
for the applications, using the package.
