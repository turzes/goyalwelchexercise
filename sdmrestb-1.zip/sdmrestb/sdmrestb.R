#/**************************************************************************************************************************
#		
#		This program computes the KMM test statistic with subsample bootstrap 
#First and Second order Stochastic Dominance		
#Centered and uncentered (nc) bootstrap 
#Oliver Linton 7/2/07
# ----------------------------------------------------------------------------
# The original program in Gauss by Prof. Oliver Linton is available from : 
# https://sites.google.com/site/oliverlinton/research/software
# Meiling He Mh590@cam.ac.uk University of Cambrige
###############################################################################		

rm(list = ls(all=TRUE))		
## Please change the following line to set to your own working directory -----
mywd="C:/Users/Meiling/workspace/myRproj/sdmrestb"
setwd(mywd)
## ---------------------------------------------------



# subfunctions
source("./Function/vq_vm.R")
source("./Function/fy_vm.R")
source("./Function/mcfad.R")
source("./Function/bootp_vm.R")

seed <- 12357; 
set.seed(seed) 

# load data
djr <- read.table("djr.txt") # result is a data frame use attach? 


djr <- data.matrix(djr)

#/* load in the data; the current version has data in a file djr 
#*/

data <- log(djr[2:3131,1:2]) - log( djr[1:3130,1:2])   

n <- nrow(data) 

q <- n 
y1 <- as.matrix(data[,1]) 
y2 <- as.matrix(data[,2]) 
y <- cbind(y1,y2) 


nbs <- 1000 ; #/** This is the number of bootstrap repetitions **/
		
		
mftest1b <- matrix(data=0,nrow=nbs,ncol=1)
mftest2b <- matrix(data=0,nrow=nbs,ncol=1)
mftest1bnc <- matrix(data=0,nrow=nbs,ncol=1) 
mftest2bnc <- matrix(data=0,nrow=nbs,ncol=1) 

#/**		Compute the empirical distributions using actual data		**/
		
a <- 0.02  #/* a is the trim rate in the evaluation points */
ss <- as.matrix(rbind(y1,y2))
ss <- as.matrix(sort(ss))
sst <- as.matrix(ss[round(1+a*2*n):ceiling((1-a)*2*n-1),1] )

v <- vq_vm(sst,q)					#/** computing partition points  **/

#/** compute empirical distributions ***/

csfy1 <- fy_vm(y1,v)
cfy1 <- csfy1$cf
sfy1 <- csfy1$sf

csfy2 <- fy_vm(y2,v)
cfy2 <- csfy2$cf
sfy2 <- csfy2$sf


mxm1t <- mcfad(cfy1,cfy2) #/* Compute the test statistics */
mxm2t <- mcfad(sfy1,sfy2)

mftest1 <- sqrt(n)*mxm1t 
mftest2 <- sqrt(n)*mxm2t 


bs <- 1 
while (bs<=nbs) {
	#/* Draw bootstrap data */
	
	
	ys  <- bootp_vm(y) 

	ys1 <- as.matrix(ys[,1]) 
	ys2 <- as.matrix(ys[,2])
	
#/* Compute Bootstrap Test Statistic */
#/** compute empirical distributions ***/
	
	csfys1 <- fy_vm(ys1,v)
	cfys1 <- csfys1$cf
	sfys1 <- csfys1$sf
	
	
	csfys2 <- fy_vm(ys2,v)
	cfys2 <- csfys2$cf
	sfys2 <- csfys2$sf
	
	mxm1ts <- mcfad(cfys1-cfy1,cfys2-cfy2)
	mxm2ts <- mcfad(sfys1-sfy1,sfys2-sfy2)
	
	mftest1b[bs]<-sqrt(n)*mxm1ts 
	mftest2b[bs]<-sqrt(n)*mxm2ts 
	
	
	mxm1ts <- mcfad(cfys1,cfys2)
	mxm2ts <- mcfad(sfys1,sfys2)
	
	mftest1bnc[bs]<-sqrt(n)*mxm1ts 
	mftest2bnc[bs]<-sqrt(n)*mxm2ts 
	
	
	
	bs<-bs+1 
	
	
}

ind1 <- rank(rbind(mftest1,mftest1b),ties.method= "max")
ind2 <- rank(rbind(mftest2,mftest2b),ties.method= "max")

p1 <- 1- ind1[1]/(nbs+1) ;
p2 <- 1- ind2[1]/(nbs+1) ;

ind1nc <- rank(rbind(mftest1,mftest1bnc),ties.method= "max")
ind2nc <- rank(rbind(mftest2,mftest2bnc),ties.method= "max")

p1nc <- 1- ind1nc[1]/(nbs+1) ;
p2nc <- 1- ind2nc[1]/(nbs+1) ;


result <- rbind(c(p1,p2),c(p1nc,p2nc))
rownames(result) <- c("Pvalues for Centered Bootstrap","Pvalues for UnCentered Bootstrap")

print(result)
