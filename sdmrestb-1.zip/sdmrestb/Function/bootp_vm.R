# TODO: Add comment
# #/* standard pair bootstrap algorithm (vm) */
# Author: Meiling
###############################################################################

bootp_vm <- function(x){
	
	n <- nrow(x)
	y <- x[trunc(runif(n)*n)+1,]	
	return(y)
}

