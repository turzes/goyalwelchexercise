# TODO: Add comment
# #/* compute partition points (vm) */
# Author: Meiling
###############################################################################

vq_vm <- function (s,q){
	
	a <- max(apply(s,2,min));
	b <- min(apply(s,2,max));
	
	c <- as.matrix(seq(to=b,by=(b-a)/q,length.out=q+1))
	
	return( c)
	
	
	
	
}