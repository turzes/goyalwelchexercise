# TODO: Add comment
# #/* McFadden's test */
# Author: Meiling
###############################################################################

mcfad <- function(f,g){
	
	
	stat = apply( rbind(apply( (f - g),2,max ) , apply(( g - f ),2,max ) ),2,min); 

	
	return(stat)
	
}

