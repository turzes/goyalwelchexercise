# TODO: Add comment
# #/* compute empirical distribution, cumulative distribution and the cumulative of the cumulative distribution  */
# Author: Meiling
###############################################################################

fy_vm <- function(x,v){
	
	f_temp  <-  hist(sort(x[x<=max(v),1]),breaks=c(-Inf,v), plot =  FALSE) 
	f <- f_temp$counts
	cf  <-  cumsum(f)/nrow(x) 
	wr  <-  ( max(v)-min(v) )/nrow(v) 
	sf  <-  cumsum(cf)*wr  ;
	
	result <- list(cf=as.matrix(cf),sf=as.matrix(sf))
	return( result)
	
	
}

